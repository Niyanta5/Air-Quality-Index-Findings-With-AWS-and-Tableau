import json
import mysql.connector
from mysql.connector import errorcode

def lambda_handler(event, context):
    rds_endpoint = 'database-2.cb4qo4ewio8w.us-east-2.rds.amazonaws.com'
    rds_username = 'admin'
    rds_password = 'abc12345'
    rds_port = '3306'
    rds_db_name = 'AQI'

    try:
        connection = mysql.connector.connect(
            host=rds_endpoint,
            user=rds_username,
            password=rds_password,
            database=rds_db_name,
            port = rds_port
        )
     
    except mysql.connector.Error as err:
        print("Error connecting to database:", err)

    cursor = connection.cursor()

    procedure_name = "create_and_populate_aqi_db" 
    try:
        cursor.callproc(procedure_name)  
        connection.commit()  # Commit changes to the database
    except mysql.connector.Error as err:
        print("Error calling procedure:", err)
    connection.rollback()  # Rollback if there's an error

    
    cursor.close()
    connection.close()
