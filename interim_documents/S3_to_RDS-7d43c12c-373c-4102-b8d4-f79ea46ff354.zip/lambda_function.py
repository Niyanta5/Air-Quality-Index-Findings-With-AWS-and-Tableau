import json
from sqlalchemy import create_engine
import pandas as pd

def lambda_handler(event, context):
    
    
    df_no2 = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-merged/no2_merged.csv")
    df_co = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-merged/co_merged.csv")
    df_ozone = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-merged/ozone_merged.csv")
    df_pm_ten = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-merged/pm10_merged.csv")
    df_pm_two_point_five = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-merged/pm25_merged.csv")
    
    # Setting the RDS credentials 
    rds_endpoint = 'database-2.cb4qo4ewio8w.us-east-2.rds.amazonaws.com'
    rds_port = '3306'
    rds_db_name = 'AQI'
    rds_username = 'admin'
    rds_password = 'abc12345'

    # Connecting to RDS 
    engine = create_engine(f'mysql+pymysql://{rds_username}:{rds_password}@{rds_endpoint}:{rds_port}/{rds_db_name}')

    table_name1 = "Ozone"  
    table_name2 = "Carbon Monoxide"  
    table_name3 = "PM2.5" 
    table_name4 = "PM10"  
    table_name5 = "Nitrogen Dioxide"  

    # Write the data to SQL
    df_ozone.to_sql(table_name1, con=engine, if_exists='replace', index=False)
    df_co.to_sql(table_name2, con=engine, if_exists='replace', index=False)
    df_pm_two_point_five.to_sql(table_name3, con=engine, if_exists='replace', index=False)
    df_pm_ten.to_sql(table_name4, con=engine, if_exists='replace', index=False)
    df_no2.to_sql(table_name5, con=engine, if_exists='replace', index=False)
