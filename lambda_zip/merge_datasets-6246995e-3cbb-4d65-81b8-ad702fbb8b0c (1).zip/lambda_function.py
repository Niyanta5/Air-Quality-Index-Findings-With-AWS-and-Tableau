import json
import boto3
from botocore.exceptions import ClientError
import pandas as pd
from sqlalchemy import create_engine

def upload_s3(filename,df):
    s3 = boto3.client('s3')
    pathname = 'ia-final-project'
    file = "%s%s.csv"%(pathname,filename) 
    transformed_csv = df.to_csv(index=False)
    s3.put_object(Body=transformed_csv, Bucket=pathname, Key=filename)

def read_file(bucket, key):
    try:
        s3 = boto3.client('s3')
        obj = s3.get_object(Bucket=bucket, Key=key)
        df = pd.read_csv(obj['Body'])
        return df
    except ClientError as ex:
        if ex.response['Error']['Code'] == 'NoSuchKey':
            print("Key doesn't match. Please check the key value entered.")

def merge_api_csv(df_api,df_csv):
    columns_to_drop = ['sample_duration_code', 'validity_indicator' , 'cbsa_code']
    if any(col in df_api.columns for col in columns_to_drop):
        df_api.drop(columns=columns_to_drop, inplace=True)
    df_combined = pd.concat([df_api, df_csv], ignore_index=True)
    return df_combined

def handle_duplicates_average(df,param):
  """
  Finds rows with identical values in specified columns and aggregates "Arithmetic Mean" using average.

  Args:
      df (DataFrame): The DataFrame containing potential duplicates.

  Returns:
      DataFrame: The DataFrame with duplicates averaged based on "Arithmetic Mean".
  """
  # Define columns to check for identical values
  check_cols = ['State Code', 'County Code', 'Latitude', 'Longitude', 'Parameter Name', 'Date Local','State Name', 'County Name',
       'City Name',f'AQI {param}',f'1st Max Value {param}',f'1st Max Hour {param}']

  # Group DataFrame by the check columns
  grouped_df = df.groupby(check_cols)

  # Calculate the average of "Arithmetic Mean" within each group
  averaged_df = grouped_df[f'Arithmetic Mean {param}'].mean().reset_index()

  return averaged_df

def lambda_handler(event, context):
    
    # Reading the API Files from S3 Bucket
    
    df_no2 = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-api-files/2022_no2_api.csv")
    df_co = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-api-files/2022_co_api.csv")
    df_ozone = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-api-files/2022_ozone_api.csv")
    df_pm_ten = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-api-files/2022_pm_10_api.csv")
    df_pm_two_point_five = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-api-files/2022_pm_2.5_api.csv")
        
    # Reading the 2023 CSV Files
   
    df_pm_2_point_5_csv = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-csv-files/pm2.5_2023.csv")
    df_pm_10_csv = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-csv-files/pm10_2023.csv")
    df_co_csv = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-csv-files/co_2023.csv")
    df_no2_csv = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-csv-files/no2_2023.csv")
    df_ozone_csv = pd.read_csv("https://ia-final-project.s3.us-east-2.amazonaws.com/final-project-csv-files/ozone_2023.csv")
        
    
    
    # We have to remove the following columns 
    columns_to_remove = ['Site Num', 'POC','Parameter Code','Datum','Sample Duration',
                     'Pollutant Standard','Units of Measure','Event Type','Observation Count',
                     'Method Code', 'Method Name','Local Site Name','Address','CBSA Name', 'Date of Last Change','Observation Percent',
                     'Parameter Name','Unnamed: 0']
                     
    
    # Dropping the not required columns
    df_ozone_csv.drop(columns=columns_to_remove, inplace=True)
    df_pm_2_point_5_csv.drop(columns=columns_to_remove, inplace=True)
    df_pm_10_csv.drop(columns=columns_to_remove, inplace=True)
    df_co_csv.drop(columns=columns_to_remove, inplace=True)
    df_no2_csv.drop(columns=columns_to_remove, inplace=True)                         
    
    
    df_ozone_csv.rename(columns={'Arithmetic Mean': 'Arithmetic Mean Ozone', '1st Max Value': '1st Max Value Ozone','1st Max Hour': '1st Max Hour Ozone','AQI': 'AQI Ozone'}, inplace=True)
    df_pm_2_point_5_csv.rename(columns={'Arithmetic Mean': 'Arithmetic Mean PM 2.5', '1st Max Value': '1st Max Value PM 2.5','1st Max Hour': '1st Max Hour PM 2.5','AQI': 'AQI PM 2.5'}, inplace=True)
    df_pm_10_csv.rename(columns={'Arithmetic Mean': 'Arithmetic Mean PM 10', '1st Max Value': '1st Max Value PM 10','1st Max Hour': '1st Max Hour PM 10','AQI': 'AQI PM 10'}, inplace=True)
    df_co_csv.rename(columns={'Arithmetic Mean': 'Arithmetic Mean CO', '1st Max Value': '1st Max Value CO','1st Max Hour': '1st Max Hour CO','AQI': 'AQI CO'}, inplace=True)
    df_no2_csv.rename(columns={'Arithmetic Mean': 'Arithmetic Mean NO2', '1st Max Value': '1st Max Value NO2','1st Max Hour': '1st Max Hour NO2','AQI': 'AQI NO2'}, inplace=True)

                     
    # Combining the csv files from 2023 and api files from 2022    
    df_combined_ozone = merge_api_csv(df_ozone,df_ozone_csv)
    df_combined_pm_two_point_five = merge_api_csv(df_pm_two_point_five,df_pm_2_point_5_csv)
    df_combined_pm_ten = merge_api_csv(df_pm_ten,df_pm_10_csv)
    df_combined_co = merge_api_csv(df_co,df_co_csv)
    df_combined_no2 = merge_api_csv(df_no2,df_no2_csv)

    # Converting State Code and County Code to INT
    df_combined_ozone['State Code'] = df_combined_ozone['State Code'].astype(int)
    df_combined_ozone['County Code'] = df_combined_ozone['County Code'].astype(int)

    df_combined_pm_two_point_five['State Code'] = df_combined_pm_two_point_five['State Code'].astype(int)
    df_combined_pm_two_point_five['County Code'] = df_combined_pm_two_point_five['County Code'].astype(int)

    df_combined_pm_ten['State Code'] = df_combined_pm_ten['State Code'].astype(int)
    df_combined_pm_ten['County Code'] = df_combined_pm_ten['County Code'].astype(int)

    df_combined_co['State Code'] = df_combined_co['State Code'].astype(int)
    df_combined_co['County Code'] = df_combined_co['County Code'].astype(int)

    df_combined_no2['State Code'] = df_combined_no2['State Code'].astype(int)
    df_combined_no2['County Code'] = df_combined_no2['County Code'].astype(int)
    
    # Drop Duplicates 
    
    df_ozone_without_duplicates = df_combined_ozone.drop_duplicates()
    df_pm_two_point_five_without_duplicates = df_combined_pm_two_point_five.drop_duplicates()
    df_pm_10_without_duplicates = df_combined_pm_ten.drop_duplicates()
    df_co_without_duplicates = df_combined_co.drop_duplicates()
    df_NO2_without_duplicates = df_combined_no2.drop_duplicates()
    
    upload_s3('final-project-merged/ozone_merged.csv',df_ozone_without_duplicates)
    upload_s3('final-project-merged/no2_merged.csv',df_NO2_without_duplicates)
    upload_s3('final-project-merged/pm10_merged.csv',df_pm_10_without_duplicates)
    upload_s3('final-project-merged/pm25_merged.csv',df_pm_two_point_five_without_duplicates)
    upload_s3('final-project-merged/co_merged.csv',df_co_without_duplicates)
    
    


